<ul class="blog-rig-list">

<? foreach ($categoris as $categori) { ?>	
  <li><a href="#"><?=$categori->name?></a></li>
<?}?>
 </ul>
