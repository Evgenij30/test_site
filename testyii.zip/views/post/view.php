
<code><?_FILE_?></code>

<?=$postid[0]->name_text?>
<br>
<?=$postid[0]->text?>
